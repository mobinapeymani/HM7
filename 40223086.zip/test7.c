#include<stdio.h>
#include<ctype.h>
#include<string.h>

int main(){
    
int n;
printf("enter n :");
scanf("%d",&n);
char language_1[n][20];
char language_2[n][20];
for(int i =0;i<n;i++){
    printf("enter words just capital or small:");
    scanf("%s", language_1[i]);
    scanf("%s", language_2[i]);
}
char sentence [200];
char cpy2 [200];
char words[100][100];
int test=0;
while(getchar()!='\n');
printf("enter a sentence :");
gets(sentence);
if(islower(sentence[0]))
        test=1;


int count =0;
int lenth=0;
for(int i =0; i<=strlen(sentence);i++){
    if(sentence[i]==' '|| sentence[i]=='\0'){
        words[count][lenth]='\0';
        lenth=0;
        count++;
    }
    else{
        if(test==1){
            words[count][lenth]=tolower(sentence[i]);
            lenth++;
        }
        else{
            words[count][lenth]=toupper(sentence[i]);
            lenth++;
        }
        
    }
}
int index[n];

int flag =0;

for(int x =0;x<count;x++)
{
    for(int y=0;y<n;y++)
    {
        flag =0;
        if(strlen(words[x])==strlen(language_1[y]))
        {
          
            for(int q=0;q<strlen(words[x]);q++)
            {
                if(words[x][q]!=language_1[y][q])
                {
                    flag=1;
                    break;
                }             
            }
            if(flag==0)
            {
                index[x]=y;
             
                break;
            }
        }
        
    }
}

char cpy3[200][100];
for(int p=0;p<count;p++){
        if(strlen(language_2[index[p]])<strlen(words[p]))
            strcpy(cpy3[p],language_2[index[p]]);
      
        else{
          strcpy(cpy3[p],words[p]);
        }
  
  }
  for(int u=0;u<count;u++)
    printf("%s ",cpy3[u]);

   return 0;}